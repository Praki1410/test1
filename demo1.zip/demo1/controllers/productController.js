const Product = require('../model/productModel');
const { validateProduct } = require('../utils/validation');
// const fs = require('fs');
const fs = require('fs').promises; 
const path = require('path');



exports.createProduct = async (req, res) => {
  try {
    // Validate request body
    const { error } = validateProduct(req.body);
    if (error) {
      return res.status(400).json({ message: error.details[0].message });
    }
    
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ message: 'Product images are required' });
    }
    
    const { name, price } = req.body;
    const images = req.files.map(file => file.path);
    const user_id = req.user.id;
  
    const productId = await Product.create({
      user_id,
      name,
      price,
      image: JSON.stringify(images) 
    });
    
    const product = await Product.findById(productId);
    
    res.status(201).json({
      message: 'Product created successfully',
      product
    });
  } catch (error) {
    console.error('Create product error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};



exports.getAllProducts = async (req, res) => {
  try {
    const products = await Product.getAll();
    res.json({ products });
  } catch (error) {
    console.error('Get all products error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.getUserProducts = async (req, res) => {
  try {
    const userId = req.user.id;
    const products = await Product.findByUserId(userId);
    res.json({ products });
  } catch (error) {
    console.error('Get user products error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};



exports.updateProduct = async (req, res) => {
  try {
    const productId = req.params.id;
    const userId = req.user.id;
    
    // Check if product exists and belongs to user
    const isOwner = await Product.isOwner(productId, userId);
    if (!isOwner) {
      return res.status(403).json({ message: 'Unauthorized to update this product' });
    }
    
    // Get current product to get current image paths
    const currentProduct = await Product.findById(productId);
    if (!currentProduct) {
      return res.status(404).json({ message: 'Product not found' });
    }
    
    // Validate request body
    const { error } = validateProduct(req.body);
    if (error) {
      return res.status(400).json({ message: error.details[0].message });
    }
    
    const { name, price } = req.body;
    let images = currentProduct.images || []; // Existing images, default to empty array if none

    // If new images are uploaded
    if (req.files && req.files.length > 0) {
      // Ensure no more than 5 images
      if (req.files.length > 5) {
        return res.status(400).json({ message: 'You can upload up to 5 images only' });
      }
      
      // Delete old images (if any)
      for (const oldImage of images) {
        try {
          await fs.stat(oldImage); // Check if file exists
          await fs.unlink(oldImage); // Delete old image
        } catch (err) {
          console.error('Error deleting old image:', err);
        }
      }

      // Add new image paths to the images array
      images = req.files.map(file => file.path);
    }

    // Update product
    const updated = await Product.update(productId, {
      name,
      price,
      images
    });

    if (!updated) {
      return res.status(400).json({ message: 'Failed to update product' });
    }
    
    const updatedProduct = await Product.findById(productId);
    
    res.json({
      message: 'Product updated successfully',
      product: updatedProduct
    });
  } catch (error) {
    console.error('Update product error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// exports.updateProduct = async (req, res) => {
//   try {
//     const productId = req.params.id;
//     const userId = req.user.id;

//     // Check if product exists and belongs to user
//     const isOwner = await Product.isOwner(productId, userId);
//     if (!isOwner) {
//       return res.status(403).json({ message: 'Unauthorized to update this product' });
//     }

//     // Get current product
//     const currentProduct = await Product.findById(productId);
//     if (!currentProduct) {
//       return res.status(404).json({ message: 'Product not found' });
//     }

//     // Validate incoming data
//     const { error } = validateProduct(req.body);
//     if (error) {
//       return res.status(400).json({ message: error.details[0].message });
//     }

//     const { name, price } = req.body;
//     let images = [];

//     // Handle new image upload
//     if (req.files && req.files.length > 0) {
//       // Check file count limit
//       if (req.files.length > 5) {
//         return res.status(400).json({ message: 'You can upload up to 5 images only' });
//       }

//       // Delete old images
//       const oldImages = JSON.parse(currentProduct.images || '[]');
//       for (const oldImage of oldImages) {
//         try {
//           await fs.unlink(oldImage);
//         } catch (err) {
//           console.error('Error deleting old image:', err.message);
//         }
//       }

//       // Save new image paths
//       images = req.files.map(file => file.path);
//     } else {
//       // Keep existing images if no new files
//       images = JSON.parse(currentProduct.images || '[]');
//     }

//     // Update product
//     const updated = await Product.update(productId, {
//       name,
//       price,
//       images: JSON.stringify(images)
//     });

//     if (!updated) {
//       return res.status(400).json({ message: 'Failed to update product' });
//     }

//     const updatedProduct = await Product.findById(productId);

//     res.json({
//       message: 'Product updated successfully',
//       product: updatedProduct
//     });
//   } catch (error) {
//     console.error('Update product error:', error.message);
//     res.status(500).json({ message: 'Server error' });
//   }
// };






exports.deleteProduct = async (req, res) => {
  try {
    const productId = req.params.id;
    const userId = req.user.id;

    // Check if product exists and belongs to user
    const isOwner = await Product.isOwner(productId, userId);
    if (!isOwner) {
      return res.status(403).json({ message: 'Unauthorized to delete this product' });
    }

    // Get product to delete image
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // Delete product image if exists
    try {
      // Check if the file exists using fs.access (works with fs.promises)
      await fs.access(product.image);
      // If file exists, delete it
      await fs.unlink(product.image);
    } catch (err) {
      // If file does not exist or any error occurs
      console.log('Error deleting product image:', err);
    }

    // Delete product from database
    const deleted = await Product.delete(productId);

    if (!deleted) {
      return res.status(400).json({ message: 'Failed to delete product' });
    }

    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    console.error('Delete product error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.getProductById = async (req, res) => {
  try {
    const productId = req.params.id;
    const product = await Product.findById(productId);
    
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    
    res.json({ product });
  } catch (error) {
    console.error('Get product error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};